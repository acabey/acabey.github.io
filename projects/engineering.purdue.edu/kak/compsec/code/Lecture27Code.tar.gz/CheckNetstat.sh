#!/bin/sh

##  CheckNetstat.sh
##  Avi Kak
##  April 17, 2016

starttime=$(date +"%s")
echo "current time : $starttime"
count=1
while true
do 
    count=`expr $count + 1`
    output=`netstat -n | grep tcp`
    echo $output
    echo "$output" | grep -q "10.0.0.3*"
    if [ $? -ne 0 ];then
        now=$(date +"%s")
        difftime=`expr $now - $starttime`
        echo "diff time is: " $difftime
        exit 0
    else
        echo "tcp socket is still open for seconds: " $count
    fi
    sleep 1
done

