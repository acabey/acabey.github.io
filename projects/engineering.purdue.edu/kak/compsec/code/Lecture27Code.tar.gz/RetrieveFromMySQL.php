<?php
    // by Avi Kak (kak@purdue.edu)
    // for a simple example of SQL Injection Attack

    $username = $_GET["user"];                                      //(A)
    $userpassword = $_GET["password"];                              //(B)
    $con = mysql_connect("localhost","$username","$userpassword");  //(C)
    if (!$con) {                                                    //(D)
        die('Could not connect: ' . mysql_error());                 //(E)
    }
    
    mysql_select_db("Manager_db", $con);                            //(F)
    
    $result = mysql_query("SELECT * FROM Operator_view");           //(G)
    
    echo "<table border='1'>                 
         <tr>                                     
         <th>Operator Name</th>                   
         <th>Equipment</th>                       
         <th>Deadline</th>                        
         </tr>";                                                    //(H)
    
    while( $row = mysql_fetch_array($result) )   {                  //(I)
        echo "<tr>";                                                //(J)
        echo "<td>" . $row['operator_name'] . "</td>";              //(K)
        echo "<td>" . $row['equipment'] . "</td>";                  //(L)
        echo "<td>" . $row['deadline'] . "</td>";                   //(M)
        echo "</tr>";                                               //(N)
    }
    echo "</table>";                                                //(O)
    
    mysql_close($con);                                              //(P)
?>
