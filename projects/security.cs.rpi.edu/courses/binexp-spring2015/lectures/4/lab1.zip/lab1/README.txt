--------------------------------------------------------------------------------
Modern Binary Exploitation - CSCI 4968
Laboratory 1 - Reverse Engineering
--------------------------------------------------------------------------------
Due 2/13/2015 1:59PM EST.
Submissons must be emailed to mbespring2015@gmail.com
After 1:59PM, there will be a 10% penalty for each 24 hour period.
--------------------------------------------------------------------------------

lab1 (C grade):
What is the password? Demostrate in person to a TA how you found it.

-------------------------------------

lab2 (B grade):
What is the password? Demonstrate in person or write a document explaning how
you found the password. Your document may include screenshots to help your
explanation.

-------------------------------------

lab3 (A grade):
What is the serial number that corresponds to your last name? You may capitalize
the first letter or leave them all lower case, whichever you find easier. If
your last name is not at least 5 letters long, you will repeat it until it
reaches 5 letters. Example: last name Xu would be entered as Xuxux or xuxux.

You must explain the algorithm to which the program generates a serial based 
on your name. You may use screenshots to help your explanation.

--------------------------------------------------------------------------------

Please read the syllabus for a more detailed grading criteria

